package program;

//Importando bibliotecas necessárias
import java.io.IOException;
import java.util.Scanner;

import model.Endereco;
import service.ViaCepService;

public class Programa {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		String cep;
		
		System.out.print("Digite seu CEP=  ");
		cep = ler.next();
		
		ViaCepService viacepservice = new ViaCepService();
		
        try {
            Endereco endereco = viacepservice.getEndereco(cep);
           
            String cep1 = endereco.getCep();
            String logradouro = endereco.getLogradouro();
            String complemento = endereco.getComplemento();
            String bairro = endereco.getBairro();
            String uf = endereco.getUf();
           
            System.out.println("CEP=  "+ cep1 + " , \n"+
			     			   "LOGRADOURO=  "+ logradouro + " , " + complemento + " , \n" +
			    			   "BAIRRO=  " + bairro + " , \n" +
			    			   "CIDADE=  " + uf);
           
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }  
        ler.close();
	}

}
