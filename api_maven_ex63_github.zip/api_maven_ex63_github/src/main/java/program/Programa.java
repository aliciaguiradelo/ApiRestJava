package program;

import java.io.IOException;
import java.util.Scanner;

import model.Usuario;
import service.GitHubAPI;

public class Programa {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		String login;
		
		System.out.print("Digite o login desejado=  ");
		login = ler.next();
		
		GitHubAPI githubapi = new GitHubAPI();


        try {
            Usuario usuario = githubapi.getUsuario(login);
           
            String login1 = usuario.getLogin();
            String name = usuario.getName();
            String public_repos = usuario.getPublic_repos();
            String followers = usuario.getFollowers();
           
            System.out.println("LOGIN=  "+ login1 + " , \n"+
			      			   "NOME=  "+ name + " , \n" +
			     			   "QUANTIDADE DE REPOSITÓRIOS=  " + public_repos + " , \n" +
			     			   "QUANTIDADE DE SEGUIDORES=  " + followers);
           
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }  
        ler.close();
	}
}
