package model;

public class Usuario {
	
	//Declarendo os atributos que serão utilizados
	private String login;
	private String name;
	private String public_repos;
	private String followers;
	
	//Getters and setters dos atributos
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPublic_repos() {
		return public_repos;
	}
	public void setPublic_repos(String public_repos) {
		this.public_repos = public_repos;
	}
	public String getFollowers() {
		return followers;
	}
	public void setFollowers(String followers) {
		this.followers = followers;
	}
	
	//Sobrescrita do método
	@Override
    public String toString() {
        return "LOGIN=  "+ login + " , \n"+
 			   "NOME=  "+ name + " , \n" +
 			   "QUANTIDADE DE REPOSITÓRIOS=  " + public_repos + " , \n" +
 			   "QUANTIDADE DE SEGUIDORES=  " + followers;
    }


}
