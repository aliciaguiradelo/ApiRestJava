package program;

import java.io.IOException;
import java.util.Scanner;

import model.Cadastro;
import service.ViaCepService;


public class Programa {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		ViaCepService viacepservice = new ViaCepService();
		
		String cep = null;
		
		System.out.println("Digite seu cep:  ");
        cep = ler.next();
		
		try {
            Cadastro cadastro = viacepservice.getCadastro(cep);
            
            cadastro.setCep(cep);
            
            System.out.println("Digite seu nome:  ");
            cadastro.setNome(ler.next());
            
            System.out.println("Digite seu email:  ");
            cadastro.setEmail(ler.next());
            
            System.out.println(cadastro.getNome()  + "\n");
            System.out.println(cadastro.getEmail()  + "\n");
            System.out.println(cadastro.getCep() + "\n");
            System.out.println(cadastro.getLogradouro() + "\n");
            System.out.println(cadastro.getNumero()  + "\n");
            System.out.println(cadastro.getComplemento()  + "\n");
            System.out.println(cadastro.getBairro()  + "\n");
            System.out.println(cadastro.getUf()  + "\n");

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }  
		ler.close();
	}

}
