package program;

//Importando bibliotecas necessárias
import java.io.IOException;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Dominio;
import service.DominioApiService;

public class Programa {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		String fqdn;
		
		System.out.print("Digite o dominio que deseja consultar:  ");
		fqdn = ler.next();
		
		DominioApiService dominioapiservice = new DominioApiService();
		
        try {
        	Dominio dominio = dominioapiservice.getDominio(fqdn);
           
            @SuppressWarnings("unused")
			String site1 = dominio.getFqdn();
            String status = dominio.getStatus();
            String expiresAt = dominio.getExpires();
           
            if (status == "AVAILABLE") {
            	System.out.println("Domínio=  "+ fqdn + " , \n"+
		     			   		   "Status=  "+ status);
            	
            }else {
            	System.out.println("Domínio=  "+ fqdn + " , \n"+
  			   		   			   "Status=  "+ status + " , \n"+
  			   		   			   "Expires at=  " + expiresAt);
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }  
        ler.close();
	}

}
          