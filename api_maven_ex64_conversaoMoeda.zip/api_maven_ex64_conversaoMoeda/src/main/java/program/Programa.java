package program;

import java.io.IOException;
import java.util.Scanner;

import model.Moeda;
import service.ApiConversor;

public class Programa {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double valor;                                      
		int opcao;
		
		System.out.print("Qual valor em R$ =  ");
		valor = ler.nextDouble();
		
		System.out.print("Deseja converter para: \n"+ 
						 "1. Dólar \n" +
						 "2. Euro \n" +
						 "3. Bitcoin \n");
		System.out.print("A opção escolhida: ");
		opcao=ler.nextInt();
		
		System.out.println("A opção escolhida foi: " + opcao);
		
		ApiConversor apiconversor = new ApiConversor();
		
		try {
            Moeda moeda = apiconversor.getMoeda(opcao);
           
            float ask = moeda.getAsk();
           
            System.out.println("RESULTADO=  "+ (ask*valor));
           
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }  
        ler.close();
		
	}

}
