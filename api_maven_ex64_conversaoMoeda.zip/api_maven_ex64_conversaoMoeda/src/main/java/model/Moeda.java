package model;

public class Moeda {

	private float ask;

	public float getAsk() {
		return ask;
	}

	public void setAsk(float ask) {
		this.ask = ask;
	}

}
